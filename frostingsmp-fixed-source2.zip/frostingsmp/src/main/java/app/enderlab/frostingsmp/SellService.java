package app.enderlab.frostingsmp;

import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.BundleMeta;
import org.bukkit.inventory.meta.ItemMeta;

public final class SellService {

    public record Result(int items, double earned) {
    }

    private final FrostingSMP plugin;

    public SellService(FrostingSMP plugin) {
        this.plugin = plugin;
    }

    /**
     * Price for one unit of this stack, or null if it can't be sold. Every item can be sold,
     * except shulker boxes and bundles that still have items inside (those would be lost).
     */
    public Double priceFor(ItemStack stack) {
        if (stack == null || stack.getType().isAir() || hasContents(stack)) {
            return null;
        }
        return plugin.getShopConfig().sellPrice(stack.getType());
    }

    private boolean hasContents(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta instanceof BlockStateMeta blockMeta && blockMeta.hasBlockState()
                && blockMeta.getBlockState() instanceof ShulkerBox box) {
            return !box.getInventory().isEmpty();
        }
        if (meta instanceof BundleMeta bundle) {
            return bundle.hasItems();
        }
        return false;
    }

    public Result sellAll(Player player) {
        PlayerInventory inventory = player.getInventory();
        int items = 0;
        double earned = 0.0;

        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (stack == null || stack.getType().isAir()) {
                continue;
            }
            Double price = priceFor(stack);
            if (price == null) {
                continue;
            }
            items += stack.getAmount();
            earned += price * stack.getAmount();
            inventory.setItem(slot, null);
        }

        return new Result(items, earned);
    }

    public Result sellAndPay(Player player) {
        Result result = sellAll(player);
        if (result.items() > 0) {
            plugin.getEconomy().depositPlayer(player, result.earned());
        }
        return result;
    }
}
