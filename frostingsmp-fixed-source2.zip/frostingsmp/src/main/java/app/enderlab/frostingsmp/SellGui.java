package app.enderlab.frostingsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public final class SellGui {

    public static final class Holder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }

    private static final int SIZE = 54;

    private final FrostingSMP plugin;

    public SellGui(FrostingSMP plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Holder holder = new Holder();
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Sell Items - close to sell", NamedTextColor.DARK_GRAY));
        holder.setInventory(inventory);
        player.openInventory(inventory);
    }

    /** Sells sellable items in the closed GUI and hands everything else back. */
    public void handleClose(Player player, Inventory inventory) {
        int items = 0;
        double earned = 0.0;
        boolean returned = false;

        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (stack == null || stack.getType().isAir()) {
                continue;
            }
            inventory.setItem(slot, null);
            Double price = plugin.getSellService().priceFor(stack);
            if (price == null) {
                returned = true;
                Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
                for (ItemStack drop : leftover.values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), drop);
                }
                continue;
            }
            items += stack.getAmount();
            earned += price * stack.getAmount();
        }

        if (items > 0) {
            plugin.getEconomy().depositPlayer(player, earned);
            player.sendMessage(Msg.prefixed("&7You sold &6" + items + " &7items for &6$"
                    + Msg.formatMoney(earned)));
        }
        if (returned) {
            player.sendMessage(Msg.prefixed("&7Unsellable items were returned to you."));
        }
    }
}
