package app.enderlab.frostingsmp;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class ShopConfig {

    /** Items that are never shown in the shop (admin items, water bottles...). They can still be sold. */
    private static final Set<String> HIDDEN = new HashSet<>(List.of(
            "BEDROCK", "BARRIER", "LIGHT", "STRUCTURE_BLOCK", "STRUCTURE_VOID", "JIGSAW", "DEBUG_STICK",
            "KNOWLEDGE_BOOK", "SPAWNER", "TRIAL_SPAWNER", "VAULT", "REINFORCED_DEEPSLATE", "END_PORTAL_FRAME",
            "COMMAND_BLOCK", "REPEATING_COMMAND_BLOCK", "CHAIN_COMMAND_BLOCK", "COMMAND_BLOCK_MINECART",
            "PETRIFIED_OAK_SLAB", "FARMLAND", "DIRT_PATH", "BUDDING_AMETHYST", "CHORUS_PLANT", "FROGSPAWN",
            "POTION", "SPLASH_POTION", "LINGERING_POTION", "TIPPED_ARROW", "ENCHANTED_BOOK", "WRITTEN_BOOK",
            "FILLED_MAP", "TEST_BLOCK", "TEST_INSTANCE_BLOCK", "PLAYER_HEAD"));

    private final Map<ShopCategory, List<Material>> categoryItems;
    private final Map<Material, Double> buyPrices;
    private final Map<Material, Double> sellPrices;

    private ShopConfig(Map<ShopCategory, List<Material>> categoryItems,
                       Map<Material, Double> buyPrices, Map<Material, Double> sellPrices) {
        this.categoryItems = categoryItems;
        this.buyPrices = buyPrices;
        this.sellPrices = sellPrices;
    }

    public List<Material> items(ShopCategory category) {
        return categoryItems.getOrDefault(category, List.of());
    }

    /** Price to buy one unit, or null if the item is not sold in the shop. */
    public Double buyPrice(Material material) {
        return buyPrices.get(material);
    }

    /** Price paid for one unit when selling. Every real item has one. */
    public Double sellPrice(Material material) {
        return sellPrices.get(material);
    }

    public static ShopConfig load(FileConfiguration config) {
        double ratio = Math.max(0.0, config.getDouble("sell-ratio", 0.5));
        double hiddenSell = Math.max(0.0, config.getDouble("hidden-sell-price", 1.0));

        Map<ShopCategory, Double> categoryDefaults = new EnumMap<>(ShopCategory.class);
        for (ShopCategory category : ShopCategory.values()) {
            categoryDefaults.put(category,
                    config.getDouble("category-default-prices." + category.name(), category.defaultPrice()));
        }

        Map<Material, Double> buyOverrides = readPrices(config.getConfigurationSection("prices"));
        Map<Material, Double> sellOverrides = readPrices(config.getConfigurationSection("sell-prices"));

        Map<ShopCategory, List<Material>> items = new EnumMap<>(ShopCategory.class);
        for (ShopCategory category : ShopCategory.values()) {
            items.put(category, new ArrayList<>());
        }
        Map<Material, Double> buy = new LinkedHashMap<>();
        Map<Material, Double> sell = new HashMap<>();

        for (Material material : Material.values()) {
            if (!usable(material)) {
                continue;
            }
            ShopCategory category = ShopCategory.of(material);

            Double price = buyOverrides.get(material);
            if (price == null) {
                price = Pricing.gearPrice(material.name());
            }
            if (price == null) {
                price = categoryDefaults.get(category);
            }
            price = round(price);

            boolean hidden = isHidden(material);
            if (!hidden) {
                buy.put(material, price);
                items.get(category).add(material);
            }

            Double sellPrice = sellOverrides.get(material);
            if (sellPrice == null) {
                sellPrice = hidden ? hiddenSell : round(price * ratio);
            }
            sell.put(material, Math.max(0.01, sellPrice));
        }

        Comparator<Material> byName = Comparator.comparing(Material::name);
        for (List<Material> list : items.values()) {
            list.sort(byName);
        }

        return new ShopConfig(items, Collections.unmodifiableMap(buy), Collections.unmodifiableMap(sell));
    }

    private static boolean usable(Material material) {
        String name = material.name();
        return !name.startsWith("LEGACY_") && !material.isAir() && material.isItem();
    }

    private static boolean isHidden(Material material) {
        String name = material.name();
        return HIDDEN.contains(name) || name.endsWith("_COMMAND_BLOCK") || name.startsWith("INFESTED_");
    }

    private static double round(double value) {
        return Math.max(0.01, Math.round(value * 100.0) / 100.0);
    }

    private static Map<Material, Double> readPrices(ConfigurationSection section) {
        Map<Material, Double> result = new HashMap<>();
        if (section == null) {
            return result;
        }
        for (String key : section.getKeys(false)) {
            Material material = Material.matchMaterial(key.trim().toUpperCase(Locale.ROOT));
            if (material == null || material.isAir()) {
                continue;
            }
            double value = section.getDouble(key, -1.0);
            if (value >= 0.0) {
                result.put(material, value);
            }
        }
        return result;
    }
}
