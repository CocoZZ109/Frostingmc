package app.enderlab.frostingsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class SidebarManager {

    private static final String BALANCE_ENTRY = "\u00A70";
    private static final String PLAYTIME_ENTRY = "\u00A71";

    private final FrostingSMP plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public SidebarManager(FrostingSMP plugin) {
        this.plugin = plugin;
    }

    public void update(Player player) {
        PlayerData data = plugin.getDataManager().get(player);
        if (!data.isSidebar()) {
            if (boards.containsKey(player.getUniqueId())) {
                hide(player);
            }
            return;
        }

        Scoreboard board = boards.get(player.getUniqueId());
        if (board == null) {
            board = createBoard();
            boards.put(player.getUniqueId(), board);
            player.setScoreboard(board);
        }

        Team balance = board.getTeam("balance");
        Team playtime = board.getTeam("playtime");
        if (balance != null) {
            balance.setPrefix(Msg.color("&7Balance: &6$" + Msg.formatMoney(balanceOf(player))));
        }
        if (playtime != null) {
            playtime.setPrefix(Msg.color("&7Playtime: &6" + formatPlaytime(data.getPlaytimeSeconds())));
        }
    }

    public void hide(Player player) {
        boards.remove(player.getUniqueId());
        if (Bukkit.getScoreboardManager() != null) {
            player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
    }

    public void forget(UUID uuid) {
        boards.remove(uuid);
    }

    private Scoreboard createBoard() {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = board.registerNewObjective("frostingsmp", Criteria.DUMMY,
                Component.text("FrostingSMP", NamedTextColor.GOLD));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        Team balance = board.registerNewTeam("balance");
        balance.addEntry(BALANCE_ENTRY);
        Team playtime = board.registerNewTeam("playtime");
        playtime.addEntry(PLAYTIME_ENTRY);

        objective.getScore(BALANCE_ENTRY).setScore(2);
        objective.getScore(PLAYTIME_ENTRY).setScore(1);
        return board;
    }

    private double balanceOf(Player player) {
        try {
            return plugin.getEconomy().getBalance(player);
        } catch (RuntimeException exception) {
            return 0.0;
        }
    }

    private String formatPlaytime(long seconds) {
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long secs = seconds % 60L;
        return hours + "h " + minutes + "m " + secs + "s";
    }
}
