package app.enderlab.frostingsmp;

import java.util.Map;

/** Default price rules for tools and armor, based on material tier and piece. */
final class Pricing {

    private static final Map<String, Double> TIER_UNIT = Map.of(
            "WOODEN", 2.0, "LEATHER", 3.0, "STONE", 1.0, "COPPER", 8.0, "GOLDEN", 15.0,
            "IRON", 15.0, "CHAINMAIL", 20.0, "TURTLE", 8.0, "DIAMOND", 100.0);

    private static final Map<String, Integer> PIECE_UNITS = Map.of(
            "HELMET", 5, "CHESTPLATE", 8, "LEGGINGS", 7, "BOOTS", 4, "SWORD", 2,
            "AXE", 3, "PICKAXE", 3, "SHOVEL", 1, "HOE", 2, "SPEAR", 2);

    private static final double NETHERITE_INGOT = 500.0;

    private Pricing() {
    }

    /** Returns a computed price for tiered gear such as DIAMOND_SWORD, or null if the name is not gear. */
    static Double gearPrice(String name) {
        int first = name.indexOf('_');
        int last = name.lastIndexOf('_');
        if (first <= 0 || last < first) {
            return null;
        }
        String tier = name.substring(0, first);
        Integer units = PIECE_UNITS.get(name.substring(last + 1));
        if (units == null) {
            return null;
        }
        if (tier.equals("NETHERITE")) {
            return units * TIER_UNIT.get("DIAMOND") + NETHERITE_INGOT;
        }
        Double unit = TIER_UNIT.get(tier);
        if (unit == null) {
            return null;
        }
        return units * unit;
    }
}
