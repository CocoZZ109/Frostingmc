package app.enderlab.frostingsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class ShopGui {

    /** category == null means the main category menu. */
    public static final class Holder implements InventoryHolder {
        private final ShopCategory category;
        private final int page;
        private Inventory inventory;

        Holder(ShopCategory category, int page) {
            this.category = category;
            this.page = page;
        }

        public ShopCategory category() {
            return category;
        }

        public int page() {
            return page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }

    private static final int MAIN_SIZE = 36;
    private static final int[] CATEGORY_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
    private static final int MAIN_SELL_SLOT = 31;
    private static final int MAIN_CLOSE_SLOT = 35;

    private static final int CATEGORY_SIZE = 54;
    private static final int PAGE_SIZE = 45;
    private static final int PREV_SLOT = 45;
    private static final int BACK_SLOT = 49;
    private static final int NEXT_SLOT = 53;

    private final FrostingSMP plugin;

    public ShopGui(FrostingSMP plugin) {
        this.plugin = plugin;
    }

    /** Opens the main category menu. */
    public void open(Player player) {
        Holder holder = new Holder(null, 0);
        Inventory inventory = Bukkit.createInventory(holder, MAIN_SIZE,
                Component.text("Frosting Shop", NamedTextColor.DARK_GRAY));
        holder.setInventory(inventory);

        for (int slot = 0; slot < MAIN_SIZE; slot++) {
            inventory.setItem(slot, Icons.filler());
        }
        ShopCategory[] categories = ShopCategory.values();
        for (int i = 0; i < categories.length && i < CATEGORY_SLOTS.length; i++) {
            ShopCategory category = categories[i];
            int count = plugin.getShopConfig().items(category).size();
            inventory.setItem(CATEGORY_SLOTS[i], Icons.button(category.icon(),
                    category.color() + category.displayName(),
                    List.of("&7" + count + " items", "&eClick to browse")));
        }
        inventory.setItem(MAIN_SELL_SLOT, Icons.button(Material.MAGENTA_DYE, "&eSell All Items",
                List.of("&7Sells everything sellable in your inventory")));
        inventory.setItem(MAIN_CLOSE_SLOT, Icons.button(Material.BARRIER, "&cClose", List.of()));

        player.openInventory(inventory);
    }

    public void openCategory(Player player, ShopCategory category, int page) {
        List<Material> items = plugin.getShopConfig().items(category);
        int pages = Math.max(1, (items.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int current = Math.max(0, Math.min(page, pages - 1));

        Holder holder = new Holder(category, current);
        Inventory inventory = Bukkit.createInventory(holder, CATEGORY_SIZE,
                Component.text(category.displayName() + " (" + (current + 1) + "/" + pages + ")",
                        NamedTextColor.DARK_GRAY));
        holder.setInventory(inventory);

        for (int slot = PAGE_SIZE; slot < CATEGORY_SIZE; slot++) {
            inventory.setItem(slot, Icons.filler());
        }
        for (int i = 0; i < PAGE_SIZE; i++) {
            int index = current * PAGE_SIZE + i;
            if (index >= items.size()) {
                break;
            }
            inventory.setItem(i, buyIcon(items.get(index)));
        }

        if (current > 0) {
            inventory.setItem(PREV_SLOT, Icons.button(Material.ARROW, "&ePrevious page", List.of()));
        }
        if (current < pages - 1) {
            inventory.setItem(NEXT_SLOT, Icons.button(Material.ARROW, "&eNext page", List.of()));
        }
        inventory.setItem(BACK_SLOT, Icons.button(Material.BARRIER, "&cBack to categories", List.of()));

        player.openInventory(inventory);
    }

    public void handleClick(Player player, Holder holder, int slot, ClickType click) {
        if (holder.category() == null) {
            handleMainClick(player, slot);
        } else {
            handleCategoryClick(player, holder, slot, click);
        }
    }

    private void handleMainClick(Player player, int slot) {
        if (slot == MAIN_CLOSE_SLOT) {
            player.closeInventory();
            return;
        }
        if (slot == MAIN_SELL_SLOT) {
            sellEverything(player);
            return;
        }
        ShopCategory[] categories = ShopCategory.values();
        for (int i = 0; i < categories.length && i < CATEGORY_SLOTS.length; i++) {
            if (CATEGORY_SLOTS[i] == slot) {
                openCategory(player, categories[i], 0);
                return;
            }
        }
    }

    private void handleCategoryClick(Player player, Holder holder, int slot, ClickType click) {
        ShopCategory category = holder.category();
        if (slot == BACK_SLOT) {
            open(player);
            return;
        }
        if (slot == PREV_SLOT) {
            if (holder.page() > 0) {
                openCategory(player, category, holder.page() - 1);
            }
            return;
        }
        if (slot == NEXT_SLOT) {
            int total = plugin.getShopConfig().items(category).size();
            if ((holder.page() + 1) * PAGE_SIZE < total) {
                openCategory(player, category, holder.page() + 1);
            }
            return;
        }
        if (slot < 0 || slot >= PAGE_SIZE) {
            return;
        }
        if (click != ClickType.LEFT && click != ClickType.RIGHT
                && click != ClickType.SHIFT_LEFT && click != ClickType.SHIFT_RIGHT) {
            return;
        }
        List<Material> items = plugin.getShopConfig().items(category);
        int index = holder.page() * PAGE_SIZE + slot;
        if (index >= items.size()) {
            return;
        }
        Material material = items.get(index);
        int max = Math.max(1, material.getMaxStackSize());
        int quantity;
        if (click == ClickType.SHIFT_LEFT || click == ClickType.SHIFT_RIGHT) {
            quantity = max;
        } else if (click == ClickType.RIGHT) {
            quantity = Math.min(16, max);
        } else {
            quantity = 1;
        }
        buy(player, material, quantity);
    }

    private ItemStack buyIcon(Material material) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            Double buy = plugin.getShopConfig().buyPrice(material);
            Double sell = plugin.getShopConfig().sellPrice(material);
            int max = Math.max(1, material.getMaxStackSize());

            List<String> lore = new ArrayList<>();
            lore.add(Msg.color("&7Buy: &6$" + Msg.formatMoney(buy == null ? 0.0 : buy) + " &7each"));
            lore.add(Msg.color("&7Sell: &6$" + Msg.formatMoney(sell == null ? 0.0 : sell) + " &7each"));
            lore.add(Msg.color("&eLeft-click: &7buy 1"));
            if (max > 1) {
                lore.add(Msg.color("&eRight-click: &7buy " + Math.min(16, max)));
                lore.add(Msg.color("&eShift-click: &7buy " + max));
            }
            meta.setDisplayName(Msg.color("&e" + Msg.pretty(material)));
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private void buy(Player player, Material material, int quantity) {
        Double unit = plugin.getShopConfig().buyPrice(material);
        if (unit == null) {
            return;
        }
        double cost = unit * quantity;
        Economy economy = plugin.getEconomy();

        double balance = economy.getBalance(player);
        if (balance < cost) {
            player.sendMessage(Msg.prefixed("&cYou need &6$" + Msg.formatMoney(cost - balance) + " &cmore to buy this."));
            return;
        }

        EconomyResponse response = economy.withdrawPlayer(player, cost);
        if (!response.transactionSuccess()) {
            player.sendMessage(Msg.prefixed("&cTransaction failed: &7" + response.errorMessage));
            return;
        }

        give(player, material, quantity);
        player.sendMessage(Msg.prefixed("&7You bought &6" + quantity + " &7"
                + Msg.pretty(material) + " for &6$" + Msg.formatMoney(cost)));
    }

    private void give(Player player, Material material, int amount) {
        int maxStack = Math.max(1, material.getMaxStackSize());
        int remaining = amount;
        while (remaining > 0) {
            int size = Math.min(maxStack, remaining);
            ItemStack stack = new ItemStack(material, size);
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
            for (ItemStack drop : leftover.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), drop);
            }
            remaining -= size;
        }
    }

    private void sellEverything(Player player) {
        SellService.Result result = plugin.getSellService().sellAndPay(player);
        if (result.items() == 0) {
            player.sendMessage(Msg.prefixed("&cYou have nothing to sell."));
            return;
        }
        player.sendMessage(Msg.prefixed("&7You sold &6" + result.items() + " &7items for &6$"
                + Msg.formatMoney(result.earned())));
    }
}
