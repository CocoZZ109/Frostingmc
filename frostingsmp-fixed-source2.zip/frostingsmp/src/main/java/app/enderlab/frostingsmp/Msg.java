package app.enderlab.frostingsmp;

import org.bukkit.Material;

import java.util.Locale;

public final class Msg {

    public static final String PREFIX = "&8[&6FrostingSMP&8]&r ";


    private Msg() {
    }

    public static String color(String text) {
        return text == null ? "" : text.replace('&', '\u00A7');
    }

    public static String prefixed(String message) {
        return color(PREFIX + message);
    }

    private static final String[] SUFFIXES = {
            "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"
    };

    /** Short money format: 950, 1.5K, 2M, 1B, 2T ... and E-notation past Dc (e.g. 7.377E36). */
    public static String formatMoney(double amount) {
        if (Double.isNaN(amount) || Double.isInfinite(amount)) {
            return "0";
        }
        boolean negative = amount < 0;
        double abs = Math.abs(amount);
        String out;
        if (abs < 1000.0) {
            out = trim(Math.floor(abs * 100.0 + 1e-6) / 100.0, 2);
        } else {
            int index = Math.min((int) Math.floor(Math.log10(abs) / 3.0) - 1, SUFFIXES.length - 1);
            index = Math.max(index, 0);
            double value = abs / Math.pow(1000.0, index + 1);
            value = Math.floor(value * 1000.0 + 1e-4) / 1000.0;
            if (value >= 1000.0 && index < SUFFIXES.length - 1) {
                value /= 1000.0;
                index++;
            }
            if (value >= 1000.0) {
                int exponent = (int) Math.floor(Math.log10(abs));
                double mantissa = abs / Math.pow(10.0, exponent);
                if (mantissa >= 10.0) {
                    mantissa /= 10.0;
                    exponent++;
                }
                out = trim(Math.floor(mantissa * 1000.0 + 1e-4) / 1000.0, 3) + "E" + exponent;
            } else {
                out = trim(value, 3) + SUFFIXES[index];
            }
        }
        return negative ? "-" + out : out;
    }

    private static String trim(double value, int decimals) {
        String text = String.format(Locale.US, "%." + decimals + "f", value);
        if (text.indexOf('.') >= 0) {
            text = text.replaceAll("0+$", "").replaceAll("\\.$", "");
        }
        return text;
    }

    public static String pretty(Material material) {
        String[] parts = material.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.toString();
    }
}
