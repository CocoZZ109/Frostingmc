package app.enderlab.frostingsmp;

import java.util.UUID;

public final class PlayerData {

    private final UUID uuid;
    private long playtimeSeconds;
    private boolean nightVision;
    private boolean sidebar = true;
    private boolean fastCrystal = true;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() {
        return uuid;
    }

    public long getPlaytimeSeconds() {
        return playtimeSeconds;
    }

    public void setPlaytimeSeconds(long seconds) {
        this.playtimeSeconds = Math.max(0L, seconds);
    }

    public void addPlaytimeSecond() {
        this.playtimeSeconds++;
    }

    public boolean isNightVision() {
        return nightVision;
    }

    public void setNightVision(boolean nightVision) {
        this.nightVision = nightVision;
    }

    public boolean isSidebar() {
        return sidebar;
    }

    public void setSidebar(boolean sidebar) {
        this.sidebar = sidebar;
    }

    public boolean isFastCrystal() {
        return fastCrystal;
    }

    public void setFastCrystal(boolean fastCrystal) {
        this.fastCrystal = fastCrystal;
    }
}
