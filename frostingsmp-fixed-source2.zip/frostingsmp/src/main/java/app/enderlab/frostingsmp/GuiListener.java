package app.enderlab.frostingsmp;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class GuiListener implements Listener {

    private final FrostingSMP plugin;

    public GuiListener(FrostingSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        InventoryHolder holder = top.getHolder();

        boolean shop = holder instanceof ShopGui.Holder;
        boolean settings = holder instanceof SettingsGui.Holder;
        if (!shop && !settings) {
            return;
        }

        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        Inventory clicked = event.getClickedInventory();
        if (clicked == null || !clicked.equals(top)) {
            return;
        }

        int slot = event.getRawSlot();
        if (holder instanceof ShopGui.Holder shopHolder) {
            plugin.getShopGui().handleClick(player, shopHolder, slot, event.getClick());
        } else {
            plugin.getSettingsGui().handleClick(player, slot, top);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof ShopGui.Holder || holder instanceof SettingsGui.Holder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getInventory().getHolder() instanceof SellGui.Holder
                && event.getPlayer() instanceof Player player) {
            plugin.getSellGui().handleClose(player, event.getInventory());
        }
    }
}
