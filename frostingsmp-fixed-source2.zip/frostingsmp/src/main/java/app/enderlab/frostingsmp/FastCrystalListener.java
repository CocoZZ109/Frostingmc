package app.enderlab.frostingsmp;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class FastCrystalListener implements Listener {

    private final FrostingSMP plugin;

    public FastCrystalListener(FrostingSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (!plugin.getConfig().getBoolean("fast-crystal", true)) {
            return;
        }
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_BLOCK && action != Action.RIGHT_CLICK_AIR) {
            return;
        }

        Player player = event.getPlayer();
        if (!plugin.getDataManager().get(player).isFastCrystal()) {
            return;
        }
        ItemStack inHand = player.getInventory().getItemInMainHand();
        if (inHand.getType() != Material.END_CRYSTAL) {
            return;
        }

        Block clickedBlock = event.getClickedBlock();
        if (clickedBlock != null && clickedBlock.getType().isInteractable() && !player.isSneaking()) {
            return;
        }

        Block target = resolveTarget(event, player);
        if (target == null) {
            return;
        }

        event.setCancelled(true);

        Location location = target.getLocation().add(0.5, 0.0, 0.5);
        player.getWorld().spawn(location, EnderCrystal.class, crystal -> crystal.setShowingBottom(false));

        if (player.getGameMode() != GameMode.CREATIVE) {
            if (inHand.getAmount() <= 1) {
                player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            } else {
                inHand.setAmount(inHand.getAmount() - 1);
            }
        }
        player.swingMainHand();
    }

    private Block resolveTarget(PlayerInteractEvent event, Player player) {
        Block clicked = event.getClickedBlock();
        if (clicked != null) {
            Block target = clicked.getRelative(event.getBlockFace());
            return isFree(target) ? target : null;
        }

        Location eye = player.getEyeLocation();
        Block target = eye.add(eye.getDirection().multiply(2.0)).getBlock();
        return isFree(target) ? target : null;
    }

    private boolean isFree(Block block) {
        return block.getType().isAir() || block.isPassable();
    }
}
