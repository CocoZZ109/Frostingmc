package app.enderlab.frostingsmp;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class FrostingSMP extends JavaPlugin {

    private Economy economy;
    private ShopConfig shopConfig;
    private PlayerDataManager dataManager;
    private SidebarManager sidebarManager;
    private SellService sellService;
    private ShopGui shopGui;
    private SellGui sellGui;
    private SettingsGui settingsGui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        // Run on the first tick so economy plugins have registered their Vault provider.
        getServer().getScheduler().runTask(this, this::finishEnable);
    }

    private void finishEnable() {
        if (!setupEconomy()) {
            return;
        }

        this.shopConfig = ShopConfig.load(getConfig());
        this.dataManager = new PlayerDataManager(this);
        this.dataManager.loadAll();
        this.sidebarManager = new SidebarManager(this);
        this.sellService = new SellService(this);
        this.shopGui = new ShopGui(this);
        this.sellGui = new SellGui(this);
        this.settingsGui = new SettingsGui(this);

        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new FastCrystalListener(this), this);

        registerCommands();
        startTasks();

        getLogger().info("FrostingSMP enabled.");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) {
            dataManager.saveAll();
        }
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            getLogger().severe("FrostingSMP requires Vault to be installed.");
            getServer().getPluginManager().disablePlugin(this);
            return false;
        }
        RegisteredServiceProvider<Economy> registration =
                getServer().getServicesManager().getRegistration(Economy.class);
        if (registration == null) {
            getLogger().severe("FrostingSMP requires Vault to be installed.");
            getServer().getPluginManager().disablePlugin(this);
            return false;
        }
        this.economy = registration.getProvider();
        return true;
    }

    private void registerCommands() {
        PluginCommand shop = getCommand("shop");
        if (shop != null) {
            shop.setExecutor((sender, command, label, args) -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Only players can use this command.");
                    return true;
                }
                if (!player.hasPermission("frostingsmp.shop")) {
                    player.sendMessage(Msg.prefixed("&cYou don't have permission to use this command."));
                    return true;
                }
                shopGui.open(player);
                return true;
            });
        }

        PluginCommand sell = getCommand("sell");
        if (sell != null) {
            sell.setExecutor((sender, command, label, args) -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Only players can use this command.");
                    return true;
                }
                if (!player.hasPermission("frostingsmp.sell")) {
                    player.sendMessage(Msg.prefixed("&cYou don't have permission to use this command."));
                    return true;
                }
                if (args.length == 0) {
                    sellGui.open(player);
                    return true;
                }
                SellService.Result result = sellService.sellAndPay(player);
                if (result.items() == 0) {
                    player.sendMessage(Msg.prefixed("&cYou have nothing to sell."));
                    return true;
                }
                player.closeInventory();
                player.sendMessage(Msg.prefixed("&7You sold &6" + result.items() + " &7items for &6$"
                        + Msg.formatMoney(result.earned())));
                return true;
            });
        }

        PluginCommand settings = getCommand("settings");
        if (settings != null) {
            settings.setExecutor((sender, command, label, args) -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Only players can use this command.");
                    return true;
                }
                if (!player.hasPermission("frostingsmp.settings")) {
                    player.sendMessage(Msg.prefixed("&cYou don't have permission to use this command."));
                    return true;
                }
                settingsGui.open(player);
                return true;
            });
        }

        PluginCommand togglemobs = getCommand("togglemobs");
        if (togglemobs != null) {
            togglemobs.setExecutor((sender, command, label, args) -> {
                if (!sender.hasPermission("frostingsmp.togglemobs")) {
                    sender.sendMessage(Msg.prefixed("&cYou don't have permission to use this command."));
                    return true;
                }
                toggleMobSpawning();
                return true;
            });
        }
    }

    private void startTasks() {
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                dataManager.get(player).addPlaytimeSecond();
                sidebarManager.update(player);
            }
        }, 20L, 20L);

        Bukkit.getScheduler().runTaskTimer(this, () -> dataManager.saveAll(), 20L * 60L, 20L * 60L);
    }

    public void applyNightVision(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,
                PotionEffect.INFINITE_DURATION, 0, false, false, false));
    }

    public boolean isMobSpawningEnabled() {
        for (World world : Bukkit.getWorlds()) {
            Boolean value = world.getGameRuleValue(GameRule.DO_MOB_SPAWNING);
            if (value != null) {
                return value;
            }
        }
        return true;
    }

    public boolean toggleMobSpawning() {
        boolean enabled = !isMobSpawningEnabled();
        for (World world : Bukkit.getWorlds()) {
            world.setGameRule(GameRule.DO_MOB_SPAWNING, enabled);
        }

        String message = Msg.prefixed("&7Mob spawning is now &6" + (enabled ? "enabled" : "disabled") + "&7.");
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendMessage(message);
        }
        getLogger().info("Mob spawning is now " + (enabled ? "enabled" : "disabled") + ".");
        return enabled;
    }

    public Economy getEconomy() {
        return economy;
    }

    public ShopConfig getShopConfig() {
        return shopConfig;
    }

    public PlayerDataManager getDataManager() {
        return dataManager;
    }

    public SidebarManager getSidebarManager() {
        return sidebarManager;
    }

    public SellService getSellService() {
        return sellService;
    }

    public ShopGui getShopGui() {
        return shopGui;
    }

    public SellGui getSellGui() {
        return sellGui;
    }

    public SettingsGui getSettingsGui() {
        return settingsGui;
    }
}
