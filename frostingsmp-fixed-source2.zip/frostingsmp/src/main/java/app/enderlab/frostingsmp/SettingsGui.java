package app.enderlab.frostingsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.potion.PotionEffectType;

import java.util.List;

public final class SettingsGui {

    public static final class Holder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }

    private static final int SIZE = 9;
    private static final int NIGHT_VISION_SLOT = 0;
    private static final int SIDEBAR_SLOT = 1;
    private static final int MOB_SPAWNING_SLOT = 2;
    private static final int FAST_CRYSTAL_SLOT = 3;
    private static final int CLOSE_SLOT = 8;

    private final FrostingSMP plugin;

    public SettingsGui(FrostingSMP plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Holder holder = new Holder();
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Frosting Settings", NamedTextColor.DARK_GRAY));
        holder.setInventory(inventory);
        render(player, inventory);
        player.openInventory(inventory);
    }

    public void render(Player player, Inventory inventory) {
        PlayerData data = plugin.getDataManager().get(player);

        if (data.isNightVision()) {
            inventory.setItem(NIGHT_VISION_SLOT, Icons.button(Material.SEA_LANTERN, "&aNight Vision: ON",
                    List.of("&7Click to turn off")));
        } else {
            inventory.setItem(NIGHT_VISION_SLOT, Icons.button(Material.GLOWSTONE_DUST, "&cNight Vision: OFF",
                    List.of("&7Click to turn on")));
        }

        if (data.isSidebar()) {
            inventory.setItem(SIDEBAR_SLOT, Icons.button(Material.FILLED_MAP, "&aSidebar: ON",
                    List.of("&7Click to turn off")));
        } else {
            inventory.setItem(SIDEBAR_SLOT, Icons.button(Material.MAP, "&cSidebar: OFF",
                    List.of("&7Click to turn on")));
        }

        if (!player.hasPermission("frostingsmp.togglemobs")) {
            inventory.setItem(MOB_SPAWNING_SLOT, Icons.button(Material.GRAY_STAINED_GLASS_PANE,
                    "&7No permission", List.of()));
        } else if (plugin.isMobSpawningEnabled()) {
            inventory.setItem(MOB_SPAWNING_SLOT, Icons.button(Material.SPAWNER, "&aMob Spawning: ON",
                    List.of("&7Click to turn off")));
        } else {
            inventory.setItem(MOB_SPAWNING_SLOT, Icons.button(Material.BARRIER, "&cMob Spawning: OFF",
                    List.of("&7Click to turn on")));
        }

        boolean serverEnabled = plugin.getConfig().getBoolean("fast-crystal", true);
        if (data.isFastCrystal()) {
            inventory.setItem(FAST_CRYSTAL_SLOT, Icons.button(Material.END_CRYSTAL, "&aFast Crystals: ON",
                    serverEnabled
                            ? List.of("&7Place crystals instantly on any block", "&7Click to turn off")
                            : List.of("&7Disabled by the server config", "&7Click to turn off")));
        } else {
            inventory.setItem(FAST_CRYSTAL_SLOT, Icons.button(Material.GLASS, "&cFast Crystals: OFF",
                    List.of("&7Click to turn on")));
        }

        for (int slot = 4; slot <= 7; slot++) {
            inventory.setItem(slot, Icons.filler());
        }
        inventory.setItem(CLOSE_SLOT, Icons.button(Material.BARRIER, "&cClose", List.of()));
    }

    public void handleClick(Player player, int slot, Inventory inventory) {
        PlayerData data = plugin.getDataManager().get(player);

        if (slot == NIGHT_VISION_SLOT) {
            boolean enabled = !data.isNightVision();
            data.setNightVision(enabled);
            if (enabled) {
                plugin.applyNightVision(player);
            } else {
                player.removePotionEffect(PotionEffectType.NIGHT_VISION);
            }
            plugin.getDataManager().save(data);
            render(player, inventory);
            return;
        }

        if (slot == SIDEBAR_SLOT) {
            boolean enabled = !data.isSidebar();
            data.setSidebar(enabled);
            plugin.getDataManager().save(data);
            if (enabled) {
                plugin.getSidebarManager().update(player);
            } else {
                plugin.getSidebarManager().hide(player);
            }
            render(player, inventory);
            return;
        }

        if (slot == MOB_SPAWNING_SLOT) {
            if (!player.hasPermission("frostingsmp.togglemobs")) {
                return;
            }
            plugin.toggleMobSpawning();
            render(player, inventory);
            return;
        }

        if (slot == FAST_CRYSTAL_SLOT) {
            data.setFastCrystal(!data.isFastCrystal());
            plugin.getDataManager().save(data);
            render(player, inventory);
            return;
        }

        if (slot == CLOSE_SLOT) {
            player.closeInventory();
        }
    }
}
