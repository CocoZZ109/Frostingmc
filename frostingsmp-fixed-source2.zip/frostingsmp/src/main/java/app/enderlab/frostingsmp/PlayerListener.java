package app.enderlab.frostingsmp;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public final class PlayerListener implements Listener {

    private final FrostingSMP plugin;

    public PlayerListener(FrostingSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getDataManager().get(player);
        if (data.isNightVision()) {
            plugin.applyNightVision(player);
        }
        if (data.isSidebar()) {
            plugin.getSidebarManager().update(player);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getDataManager().save(plugin.getDataManager().get(player));
        plugin.getSidebarManager().forget(player.getUniqueId());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (plugin.getDataManager().get(player).isNightVision()) {
            Bukkit.getScheduler().runTask(plugin, () -> plugin.applyNightVision(player));
        }
    }
}
