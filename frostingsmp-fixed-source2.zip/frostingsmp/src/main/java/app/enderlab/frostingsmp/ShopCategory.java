package app.enderlab.frostingsmp;

import org.bukkit.Material;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

/**
 * Shop categories. The declaration order is both the menu order and the matching
 * priority: the first category that matches an item wins, MISC catches the rest.
 */
public enum ShopCategory {

    TOTEMS_COMBAT("Totems & Combat", Material.TOTEM_OF_UNDYING, "&6", 200.0,
            m -> Data.in(m, Data.COMBAT)),

    ARMOR("Armor", Material.DIAMOND_CHESTPLATE, "&b", 100.0,
            m -> Data.ends(m, "_HELMET", "_CHESTPLATE", "_LEGGINGS", "_BOOTS", "_ARMOR")
                    || Data.in(m, Data.ARMOR)),

    TOOLS("Weapons & Tools", Material.DIAMOND_SWORD, "&c", 80.0,
            m -> Data.ends(m, "_SWORD", "_AXE", "_PICKAXE", "_SHOVEL", "_HOE", "_SPEAR", "_BUCKET")
                    || Data.in(m, Data.TOOLS)),

    POTIONS("Potions & Brewing", Material.BREWING_STAND, "&d", 40.0,
            m -> Data.in(m, Data.POTIONS)),

    ORES("Ores & Minerals", Material.DIAMOND, "&3", 40.0,
            m -> Data.ends(m, "_ORE", "_INGOT", "_NUGGET") || m.name().startsWith("RAW_")
                    || Data.in(m, Data.ORES)),

    REDSTONE("Redstone & Transport", Material.REDSTONE, "&4", 15.0,
            m -> Data.ends(m, "_BUTTON", "_PRESSURE_PLATE", "_MINECART", "_BOAT", "_RAFT", "RAIL")
                    || Data.in(m, Data.REDSTONE)),

    FOOD("Food", Material.COOKED_BEEF, "&a", 8.0,
            Material::isEdible),

    MOB_DROPS("Mob Drops & Farming", Material.BONE, "&f", 15.0,
            m -> Data.ends(m, "_SEEDS") || Data.in(m, Data.MOB_DROPS)),

    PLANTS("Plants & Nature", Material.OAK_SAPLING, "&2", 2.0,
            m -> Data.ends(m, "_LEAVES", "_SAPLING", "_PROPAGULE", "_FUNGUS", "_ROOTS", "_NYLIUM",
                    "_WART_BLOCK", "_VINES", "_MUSHROOM", "_MUSHROOM_BLOCK", "_CORAL", "_CORAL_FAN",
                    "_CORAL_BLOCK", "_TULIP") || Data.in(m, Data.PLANTS)),

    WOOD("Wood", Material.OAK_LOG, "&6", 3.0,
            m -> Data.isWood(m)),

    COLORED("Colored & Decor", Material.RED_WOOL, "&e", 3.0,
            m -> Data.ends(m, "_WOOL", "_CARPET", "_BED", "_BANNER", "_DYE", "_STAINED_GLASS",
                    "_STAINED_GLASS_PANE", "_GLAZED_TERRACOTTA", "_TERRACOTTA", "_CONCRETE",
                    "_CONCRETE_POWDER", "_CANDLE", "_SHULKER_BOX", "_BANNER_PATTERN", "_HARNESS")
                    || Data.in(m, Data.COLORED)),

    BUILDING("Building Blocks", Material.STONE_BRICKS, "&7", 2.0,
            Material::isBlock),

    SPAWN_EGGS("Spawn Eggs", Material.ZOMBIE_SPAWN_EGG, "&5", 2500.0,
            m -> Data.ends(m, "_SPAWN_EGG")),

    MISC("Miscellaneous", Material.CHEST, "&9", 25.0,
            m -> true);

    private final String displayName;
    private final Material icon;
    private final String color;
    private final double defaultPrice;
    private final Predicate<Material> matcher;

    ShopCategory(String displayName, Material icon, String color, double defaultPrice,
                 Predicate<Material> matcher) {
        this.displayName = displayName;
        this.icon = icon;
        this.color = color;
        this.defaultPrice = defaultPrice;
        this.matcher = matcher;
    }

    public String displayName() {
        return displayName;
    }

    public Material icon() {
        return icon;
    }

    public String color() {
        return color;
    }

    public double defaultPrice() {
        return defaultPrice;
    }

    public static ShopCategory of(Material material) {
        for (ShopCategory category : values()) {
            if (category != MISC && category.matcher.test(material)) {
                return category;
            }
        }
        return MISC;
    }

    /** Matching helpers. Names are compared as strings so unknown names are harmless. */
    private static final class Data {

        static final Set<String> COMBAT = set("TOTEM_OF_UNDYING", "END_CRYSTAL", "ENDER_PEARL", "ENDER_EYE",
                "EXPERIENCE_BOTTLE", "GOLDEN_APPLE", "ENCHANTED_GOLDEN_APPLE", "FIREWORK_ROCKET",
                "FIREWORK_STAR", "TNT", "TNT_MINECART", "RESPAWN_ANCHOR", "FIRE_CHARGE", "WIND_CHARGE",
                "OBSIDIAN", "CRYING_OBSIDIAN", "COBWEB");

        static final Set<String> ARMOR = set("ELYTRA", "SHIELD");

        static final Set<String> TOOLS = set("BOW", "CROSSBOW", "TRIDENT", "MACE", "FISHING_ROD", "SHEARS",
                "FLINT_AND_STEEL", "ARROW", "SPECTRAL_ARROW", "CARROT_ON_A_STICK", "WARPED_FUNGUS_ON_A_STICK",
                "BRUSH", "SPYGLASS", "COMPASS", "RECOVERY_COMPASS", "CLOCK", "LEAD", "NAME_TAG", "BUCKET");

        static final Set<String> POTIONS = set("POTION", "SPLASH_POTION", "LINGERING_POTION", "TIPPED_ARROW",
                "BREWING_STAND", "CAULDRON", "BLAZE_POWDER", "GHAST_TEAR", "FERMENTED_SPIDER_EYE", "SPIDER_EYE",
                "MAGMA_CREAM", "GLISTERING_MELON_SLICE", "PHANTOM_MEMBRANE", "RABBIT_FOOT", "DRAGON_BREATH",
                "GLASS_BOTTLE", "NETHER_WART", "SUGAR");

        static final Set<String> ORES = set("DIAMOND", "EMERALD", "COAL", "CHARCOAL", "LAPIS_LAZULI", "QUARTZ",
                "AMETHYST_SHARD", "NETHERITE_SCRAP", "ANCIENT_DEBRIS", "DIAMOND_BLOCK", "IRON_BLOCK",
                "GOLD_BLOCK", "EMERALD_BLOCK", "NETHERITE_BLOCK", "LAPIS_BLOCK", "COAL_BLOCK");

        static final Set<String> REDSTONE = set("REDSTONE", "REDSTONE_BLOCK", "REDSTONE_TORCH", "REPEATER",
                "COMPARATOR", "PISTON", "STICKY_PISTON", "OBSERVER", "HOPPER", "DROPPER", "DISPENSER", "LEVER",
                "TARGET", "TRIPWIRE_HOOK", "DAYLIGHT_DETECTOR", "REDSTONE_LAMP", "NOTE_BLOCK", "JUKEBOX",
                "SLIME_BLOCK", "HONEY_BLOCK", "LIGHTNING_ROD", "SCULK_SENSOR", "CALIBRATED_SCULK_SENSOR",
                "CRAFTER", "SADDLE", "MINECART");

        static final Set<String> MOB_DROPS = set("BONE", "BONE_MEAL", "STRING", "GUNPOWDER", "BLAZE_ROD",
                "SLIME_BALL", "LEATHER", "RABBIT_HIDE", "FEATHER", "INK_SAC", "GLOW_INK_SAC", "PRISMARINE_SHARD",
                "PRISMARINE_CRYSTALS", "SHULKER_SHELL", "NAUTILUS_SHELL", "HEART_OF_THE_SEA", "TURTLE_SCUTE",
                "SCUTE", "ARMADILLO_SCUTE", "BREEZE_ROD", "NETHER_STAR", "WITHER_SKELETON_SKULL",
                "SKELETON_SKULL", "ZOMBIE_HEAD", "CREEPER_HEAD", "PIGLIN_HEAD", "DRAGON_HEAD", "PLAYER_HEAD",
                "EGG", "TURTLE_EGG", "SNIFFER_EGG", "HONEYCOMB", "WHEAT", "WHEAT_SEEDS", "CLAY_BALL", "FLINT",
                "ECHO_SHARD", "DISC_FRAGMENT_5", "GOAT_HORN", "HEAVY_CORE", "TRIAL_KEY", "OMINOUS_TRIAL_KEY",
                "OMINOUS_BOTTLE");

        static final Set<String> PLANTS = set("DANDELION", "POPPY", "BLUE_ORCHID", "ALLIUM", "AZURE_BLUET",
                "OXEYE_DAISY", "CORNFLOWER", "LILY_OF_THE_VALLEY", "TORCHFLOWER", "PITCHER_PLANT", "WITHER_ROSE",
                "SUNFLOWER", "LILAC", "ROSE_BUSH", "PEONY", "FERN", "LARGE_FERN", "SHORT_GRASS", "GRASS",
                "TALL_GRASS", "DEAD_BUSH", "SEAGRASS", "KELP", "SEA_PICKLE", "LILY_PAD", "VINE", "MOSS_BLOCK",
                "MOSS_CARPET", "AZALEA", "FLOWERING_AZALEA", "SPORE_BLOSSOM", "BIG_DRIPLEAF", "SMALL_DRIPLEAF",
                "HANGING_ROOTS", "GLOW_LICHEN", "CACTUS", "SUGAR_CANE", "BAMBOO", "COCOA_BEANS", "PUMPKIN",
                "CARVED_PUMPKIN", "JACK_O_LANTERN", "MELON", "HAY_BLOCK", "RED_MUSHROOM", "BROWN_MUSHROOM",
                "PINK_PETALS", "WILDFLOWERS", "LEAF_LITTER", "BUSH", "FIREFLY_BUSH", "CACTUS_FLOWER",
                "DRIED_KELP_BLOCK", "OPEN_EYEBLOSSOM", "CLOSED_EYEBLOSSOM", "SHROOMLIGHT");

        static final Set<String> COLORED = set("GLASS", "GLASS_PANE", "TINTED_GLASS", "TERRACOTTA", "CANDLE",
                "SHULKER_BOX", "PAINTING", "ITEM_FRAME", "GLOW_ITEM_FRAME", "FLOWER_POT", "ARMOR_STAND",
                "LANTERN", "SOUL_LANTERN", "TORCH", "SOUL_TORCH", "BOOKSHELF", "CHISELED_BOOKSHELF", "END_ROD",
                "SEA_LANTERN", "GLOWSTONE");

        static final String[] WOOD_PREFIXES = {"OAK_", "SPRUCE_", "BIRCH_", "JUNGLE_", "ACACIA_", "DARK_OAK_",
                "MANGROVE_", "CHERRY_", "PALE_OAK_", "BAMBOO_", "CRIMSON_", "WARPED_"};

        static final String[] WOOD_SUFFIXES = {"_LOG", "_WOOD", "_PLANKS", "_STAIRS", "_SLAB", "_FENCE",
                "_FENCE_GATE", "_DOOR", "_TRAPDOOR", "_SIGN", "_HANGING_SIGN", "_STEM", "_HYPHAE", "_MOSAIC",
                "_MOSAIC_STAIRS", "_MOSAIC_SLAB", "_SHELF", "_BLOCK"};

        private Data() {
        }

        static Set<String> set(String... names) {
            return new HashSet<>(Arrays.asList(names));
        }

        static boolean in(Material material, Set<String> names) {
            return names.contains(material.name());
        }

        static boolean ends(Material material, String... suffixes) {
            String name = material.name();
            for (String suffix : suffixes) {
                if (name.endsWith(suffix)) {
                    return true;
                }
            }
            return false;
        }

        static boolean isWood(Material material) {
            String name = material.name();
            if (name.startsWith("STRIPPED_")) {
                return true;
            }
            for (String prefix : WOOD_PREFIXES) {
                if (name.startsWith(prefix)) {
                    return ends(material, WOOD_SUFFIXES);
                }
            }
            return false;
        }
    }
}
