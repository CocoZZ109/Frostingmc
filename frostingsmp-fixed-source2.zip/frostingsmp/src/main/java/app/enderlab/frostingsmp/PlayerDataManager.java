package app.enderlab.frostingsmp;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class PlayerDataManager {

    private final FrostingSMP plugin;
    private final File folder;
    private final Map<UUID, PlayerData> cache = new HashMap<>();

    public PlayerDataManager(FrostingSMP plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "playerdata");
    }

    public void loadAll() {
        cache.clear();
        if (!folder.exists() && !folder.mkdirs()) {
            plugin.getLogger().warning("Could not create the playerdata folder.");
            return;
        }
        File[] files = folder.listFiles((dir, name) -> name.endsWith(".yml"));
        if (files == null) {
            return;
        }
        for (File file : files) {
            String name = file.getName().substring(0, file.getName().length() - 4);
            UUID uuid;
            try {
                uuid = UUID.fromString(name);
            } catch (IllegalArgumentException exception) {
                continue;
            }
            YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
            PlayerData data = new PlayerData(uuid);
            data.setPlaytimeSeconds(config.getLong("playtime-seconds", 0L));
            data.setNightVision(config.getBoolean("night-vision", false));
            data.setSidebar(config.getBoolean("sidebar", true));
            data.setFastCrystal(config.getBoolean("fast-crystal", true));
            cache.put(uuid, data);
        }
    }

    public PlayerData get(Player player) {
        return cache.computeIfAbsent(player.getUniqueId(), PlayerData::new);
    }

    public void save(PlayerData data) {
        if (!folder.exists() && !folder.mkdirs()) {
            return;
        }
        YamlConfiguration config = new YamlConfiguration();
        config.set("playtime-seconds", data.getPlaytimeSeconds());
        config.set("night-vision", data.isNightVision());
        config.set("sidebar", data.isSidebar());
        config.set("fast-crystal", data.isFastCrystal());
        try {
            config.save(new File(folder, data.getUuid() + ".yml"));
        } catch (IOException exception) {
            plugin.getLogger().warning("Could not save data for " + data.getUuid() + ": " + exception.getMessage());
        }
    }

    public void saveAll() {
        for (PlayerData data : cache.values()) {
            save(data);
        }
    }
}
