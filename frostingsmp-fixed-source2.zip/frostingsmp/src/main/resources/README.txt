FrostingSMP - installation
==========================

1. Drop FrostingSMP.jar into your server's plugins/ folder.
2. Make sure Vault AND an economy plugin (for example EssentialsX) are installed.
   FrostingSMP stores no money itself - all balances live in the economy plugin.
3. Restart the server.
4. Optionally edit plugins/FrostingSMP/config.yml to change shop prices.
   (If you are updating from an older version, delete the old config.yml once so the new one is generated.)
5. Use the commands below in game.

Commands
--------
/shop        - opens the shop: pick a category (armor, totems & combat, tools, food, ...) and buy items
/sell        - opens a sell menu (ANY item sells when you close it); /sell all sells your whole inventory
/settings    - opens your personal settings menu (night vision, sidebar, fast crystals, mob spawning)
/togglemobs  - toggles global mob spawning (op only)

Permissions
-----------
frostingsmp.shop        (default: everyone)
frostingsmp.sell        (default: everyone)
frostingsmp.settings    (default: everyone)
frostingsmp.togglemobs  (default: op)

Player data
-----------
Playtime and personal toggles are stored per player in
plugins/FrostingSMP/playerdata/<uuid>.yml and are saved every minute,
on quit and on shutdown.
